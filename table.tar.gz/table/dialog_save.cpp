#include "dialog_save.h"
#include "ui_dialog_save.h"
#include "ShowNowTime.h"

Dialog_save::Dialog_save(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog_save)
{
    ui->setupUi(this);
    ui->dateEdit->setDate(QDate(ShowNowTime::getYear(),ShowNowTime::getMonth(),ShowNowTime::getDay()));
    ui->dateEdit_2->setDate(QDate(ShowNowTime::getYear(),ShowNowTime::getMonth(),ShowNowTime::getDay()));
    ui->timeEdit->setTime(QTime(ShowNowTime::getHour(),ShowNowTime::getMinite(),ShowNowTime::getSecond()));
    ui->timeEdit_2->setTime(QTime(ShowNowTime::getHour(),ShowNowTime::getMinite(),ShowNowTime::getSecond()));
    ui->checkBox_2->setChecked(true);

}

Dialog_save::~Dialog_save()
{
    delete ui;
}

void Dialog_save::getInfo(Date* in)
{
    dates=in;
}

void Dialog_save::on_pushButton_clicked()
{

    int now=dates->dateNum();
    dates->setDateNum(now+1);
    cout<<"india:"<<dates->dateNum()<<endl;
    (dates+now)->setTitle(ui->lineEdit->text().toStdString());
    (dates+now)->setLocation(ui->lineEdit_2->text().toStdString());
    (dates+now)->setSTime(ui->timeEdit->time().hour(),ui->timeEdit->time().minute(),ui->timeEdit->time().second());
    (dates+now)->setSDay(ui->dateEdit->date().year(),ui->dateEdit->date().month(),ui->dateEdit->date().day());
    (dates+now)->setETime(ui->timeEdit_2->time().hour(),ui->timeEdit_2->time().minute(),ui->timeEdit_2->time().second());
    (dates+now)->setEDay(ui->dateEdit_2->date().year(),ui->dateEdit_2->date().month(),ui->dateEdit_2->date().day());
    (dates+now)->setPS(ui->textEdit->toPlainText().toStdString());
    (dates+now)->setImportant(ui->checkBox->isChecked());
    (dates+now)->setRemind(ui->checkBox_2->isChecked());
    (dates+now)->setIsdone(ui->checkBox_3->isChecked());
   this ->setLoopdate(dates+now);
    cout<<"now is "<<now<<endl;
   this->close();
}

void Dialog_save::setLoopdate(Date* datedemo)
{
    int AllDatessize=dates[0].dateNum();
    if(datedemo->getLoop().get_loopLength().getDay()!=0)
    {
        int length=datedemo->getLoop().get_loopLength().getDay();
        for(QDate datetempS=datedemo->getLoop().get_Start_DateTime().toQDate(),datetempE=datedemo->getLoop().get_End_DateTime().toQDate();
            datetempS<=datedemo->getLoop().get_End_DateTime().toQDate();
            datetempS=datetempS.addDays(length),datetempE=datetempE.addDays(length))
        {
            AllDatessize++;
            dates[AllDatessize-1]=*datedemo;
            dates[AllDatessize-1].getSDay().QDatetoDate(datetempS);
            dates[AllDatessize-1].getEDay().QDatetoDate(datetempE);
        }
    }
   else if(datedemo->getLoop().get_loopLength().getMonth()!=0)
    {
        int length=datedemo->getLoop().get_loopLength().getMonth();
        for(QDate datetempS=datedemo->getLoop().get_Start_DateTime().toQDate(),datetempE=datedemo->getLoop().get_End_DateTime().toQDate();
            datetempS<=datedemo->getLoop().get_End_DateTime().toQDate();
            datetempS=datetempS.addMonths(length),datetempE=datetempE.addMonths(length))
        {
            AllDatessize++;
            dates[AllDatessize-1]=*datedemo;
            dates[AllDatessize-1].getSDay().QDatetoDate(datetempS);
            dates[AllDatessize-1].getEDay().QDatetoDate(datetempE);
        }
    }
    dates[0].setDateNum(AllDatessize);
}


void Dialog_save::on_pushButton_ChooseLoop_clicked()
{
    int now=dates->dateNum();
    cout<<"india:"<<dates->dateNum()<<endl;
    (dates+now)->setTitle(ui->lineEdit->text().toStdString());
    (dates+now)->setLocation(ui->lineEdit_2->text().toStdString());
    //(dates+now)->setSTime(ui->timeEdit->time().hour(),ui->timeEdit->time().minute(),ui->timeEdit->time().second());
    //(dates+now)->setSDay(ui->dateEdit->date().year(),ui->dateEdit->date().month(),ui->dateEdit->date().day());
  //  (dates+now)->setETime(ui->timeEdit_2->time().hour(),ui->timeEdit_2->time().minute(),ui->timeEdit_2->time().second());
    //(dates+now)->setETime(5,0,0);
    //(dates+now)->setEDay(ui->dateEdit_2->date().year(),ui->dateEdit_2->date().month(),ui->dateEdit_2->date().day());
    (dates+now)->setPS(ui->textEdit->toPlainText().toStdString());
    dialog_loop.getInfo(dates+now);
    dialog_loop.exec();
}
