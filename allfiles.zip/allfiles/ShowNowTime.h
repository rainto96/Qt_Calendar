#ifndef SHOWNOWTIME_H
#define SHOWNOWTIME_H
class ShowNowTime
{
public:
	static int getYear();
	static int getMonth();
	static int getDay();
	static int getHour();
	static int getMinite();
	static int getSecond();
};
#endif

